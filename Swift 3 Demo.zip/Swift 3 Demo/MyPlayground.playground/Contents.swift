//: Playground - noun: a place where people can play

import UIKit

var number: Int?

print (number)

let userEnteredText = "3"

let userEnteredInteger = Int(userEnteredText)

let catAge = userEnteredInteger! * 7