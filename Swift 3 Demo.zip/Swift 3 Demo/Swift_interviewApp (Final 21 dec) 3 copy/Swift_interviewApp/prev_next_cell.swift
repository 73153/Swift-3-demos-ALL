//
//  prev_next_cell.swift
//  Swift_interviewApp
//
//  Created by heli on 12/12/16.
//  Copyright © 2016 com.zaptechsolution. All rights reserved.
//

import UIKit

class prev_next_cell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    @IBOutlet var objprevbtn: UIButton!

    @IBOutlet var objnextbtn: UIButton!
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
