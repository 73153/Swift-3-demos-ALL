//
//  ViewControllerTVCell.swift
//  Swift_interviewApp
//
//  Created by heli on 11/25/16.
//  Copyright © 2016 com.zaptechsolution. All rights reserved.
//

import UIKit

class ViewControllerTVCell: UITableViewCell {
    @IBOutlet var lbl_ques_no: UILabel!
    @IBOutlet var lbl_question: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
