//
//  ViewController.swift
//  Swift_interviewApp
//
//  Created by heli on 11/18/16.
//  Copyright © 2016 com.zaptechsolution. All rights reserved.
//

import UIKit
import GoogleMobileAds
class ViewController: UIViewController ,UITableViewDelegate ,UITableViewDataSource ,UISearchBarDelegate,UISearchResultsUpdating  {
    @available(iOS 8.0, *)
    public func updateSearchResults(for searchController: UISearchController) {
        filterContentForSearchText(searchController: searchController)
    }
    @IBOutlet var lblNorecord: UILabel!
    @IBOutlet var tblTopPosition: NSLayoutConstraint!
    @IBOutlet weak var ViewAdvertise: GADBannerView!
    @IBOutlet var view_Green: UIView!
    @IBOutlet var tblView: UITableView!
    var searchController : UISearchController!
    // var showsCancelButton: Bool
    let db = SQLiteDB.sharedInstance
    var arydata = [QueAns]()
    var filteredData = [QueAns]()
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    var isPressedSearchBtn : Bool = false
    // MARK:- View Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
//        ViewAdvertise.adUnitID = "ca-app-pub-5831605216718236/2956103704"
//        ViewAdvertise.rootViewController = self
//        ViewAdvertise.load(GADRequest())
        lblNorecord.isHidden = true
        self.navigationItem.title="All Question"
        self.GetDataFromDataBase()
        let notificationName = Notification.Name("NotificationIdentifier")
        // Register to receive notification
        self.tblView.estimatedRowHeight = 280.0
        self.tblView.rowHeight = UITableViewAutomaticDimension
        NotificationCenter.default.addObserver(self, selector: #selector(self.methodOfReceivedNotification), name: notificationName, object: nil)
        self.tblView.estimatedRowHeight = 280.0
        self.tblView.rowHeight = UITableViewAutomaticDimension
        setupsearchcontroll()
        tblView.tableHeaderView = searchController.searchBar
        definesPresentationContext = true
        self.setNavigationBarItem()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationItem.title=""
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated) // No need for semicolon
        self.GetDataFromDataBase()
        let titleDict: NSDictionary = [NSForegroundColorAttributeName: UIColor.white]
        self.navigationController?.navigationBar.titleTextAttributes = titleDict as? [String : Any]
        if(arydata.count == 0 ){
            lblNorecord.isHidden = false
            lblNorecord.text = "No record found"
            tblView.isHidden = true
            searchController.isActive = false
            self.addRightBarButtonWithImage((UIImage(named:"search-outfocused")?.withRenderingMode(.alwaysOriginal))!)
            self.navigationItem.rightBarButtonItem?.isEnabled = false
        }else{
            //            if !searchController.isActive {
            //                let searchSize = searchController.searchBar.bounds.size
            //                tblTopPosition.constant = 0
            //                    tblView.contentOffset = CGPoint(x: CGFloat(0), y: CGFloat(searchSize.height))
            //            }
        }
        DispatchQueue.main.async {
            self.tblView.reloadData()
        }
    }
    override func viewDidLayoutSubviews() {
        self.automaticallyAdjustsScrollViewInsets =  false
        self.tblView.contentInset = UIEdgeInsetsMake(-44, 0, 0, 0)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //MARK: - Search Method
    func setupsearchcontroll() {
        let cancelButtonAttributes: NSDictionary = [NSForegroundColorAttributeName: UIColor.black]
        UIBarButtonItem.appearance().setTitleTextAttributes(cancelButtonAttributes as? [String : AnyObject], for: UIControlState.normal)
        searchController = UISearchController(searchResultsController: nil)
        searchController.dimsBackgroundDuringPresentation = false
        searchController.searchBar.delegate = self
        searchController.searchBar.becomeFirstResponder()
        definesPresentationContext = true
        searchController.searchBar.placeholder = "Search here..."
        searchController.searchBar.sizeToFit()
        searchController.searchBar.barTintColor = UIColor(red: CGFloat(140 / 255.0), green: CGFloat(198 / 255.0), blue: CGFloat(37 / 255.0), alpha: CGFloat(0.0 / 255.0))
        searchController.searchBar.backgroundColor = UIColor(red: CGFloat(140 / 255.0), green: CGFloat(198 / 255.0), blue: CGFloat(37 / 255.0), alpha: CGFloat(0.0 / 255.0))
        searchController.searchResultsUpdater = self
        hidesSearchBar()
    }
    public func searchBarTextDidBeginEditing(_ searchBar: UISearchBar)  {
        if self.numberOfSections(in: self.tblView) > 0 {
        }
    }
    func methodOfReceivedNotification()
    {
        searchController.searchBar.becomeFirstResponder()
        
        if (arydata.count>0) {
            searchController.searchBar.barTintColor =  UIColor(red: CGFloat(140 / 255.0), green: CGFloat(198 / 255.0), blue: CGFloat(37 / 255.0), alpha: CGFloat(0.0 / 255.0))
            searchController.isActive = true
            searchController.searchBar.becomeFirstResponder()
            if self.numberOfSections(in: self.tblView) > 0 {
                tblTopPosition.constant = 35
                self.tblView.contentInset = UIEdgeInsetsMake(-12, 0, 0, 0)
                tblView.scrollToRow(at: IndexPath(row: 0, section: 0), at: .top, animated: false)
                //                DispatchQueue.main.async {
                //                    self.tblView.reloadData()
                //                }
            }
        }else{
            self.navigationItem.rightBarButtonItem?.isEnabled = false
        }
    }
    public func searchBarCancelButtonClicked(_ searchBar: UISearchBar)
    {
        searchController.searchBar.barTintColor = UIColor(red: CGFloat(140 / 255.0), green: CGFloat(198 / 255.0), blue: CGFloat(37 / 255.0), alpha: CGFloat(0.0 / 255.0))
        searchController.searchBar.setShowsCancelButton(true, animated: true)
        searchController.searchBar.tintColor = UIColor.black
        hidesSearchBar()
    }
    func filterContentForSearchText(searchController: UISearchController) {
        let searchString = searchController.searchBar.text
        filteredData = arydata.filter({ (country) -> Bool in
            let countryText: NSString = country.Question_Name as NSString
            return countryText.lowercased.contains(searchString!.lowercased())
        })
        if searchController.isActive && searchController.searchBar.text != "" {
            tblView.reloadData()
            
            if filteredData.count == 1
            {
                tblView.scrollToRow(at: IndexPath(row: 0, section: 0), at: .top, animated: false)
            }
        }
    }
    func hidesSearchBar () {
        searchController.isActive = false
        let searchSize = searchController.searchBar.bounds.size
        tblTopPosition.constant = 0
        tblView.contentOffset = CGPoint(x: CGFloat(0), y: CGFloat(searchSize.height))
        DispatchQueue.main.async {
            self.tblView.reloadData()
        }
    }
    @IBAction func btn_SearchNav(_ sender: AnyObject) {
    }
    public func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String){
        if searchController.searchBar.text == "" {
            searchBar.setShowsCancelButton(false, animated: true)
            searchController.searchBar.barTintColor = UIColor(red: CGFloat(140 / 255.0), green: CGFloat(198 / 255.0), blue: CGFloat(37 / 255.0), alpha: CGFloat(0.0 / 255.0))
            searchController.searchBar.setShowsCancelButton(true, animated: true)
            searchController.searchBar.tintColor = UIColor.black
            hidesSearchBar()
        }
    }
    @IBAction func toogleSideMenu(_ sender: AnyObject) {
    }
    // MARK: - UITableViewDataSource
    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    func tableView(_ tableView:UITableView, numberOfRowsInSection section:Int) -> Int {
        if searchController.isActive && searchController.searchBar.text != "" && filteredData.count > 0 {
            return filteredData.count
        }
        return arydata.count
    }
    func tableView(_ tableView:UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TaskCell",
                                                 for: indexPath) as! ViewControllerTVCell
        cell.lbl_question.font = UIFont.preferredFont(forTextStyle: .body)
        if searchController.isActive && searchController.searchBar.text != "" && filteredData.count > 0{
            lblNorecord.isHidden = true
            tblView.isHidden = false
            let task = filteredData[indexPath.row]
            let newStr:String = "Q" + String(task.Id)
            cell.lbl_ques_no?.text = newStr
            cell.lbl_question?.text = task.Question_Name
        }
        else if searchController.isActive && searchController.searchBar.text != "" && filteredData.count == 0{
            lblNorecord.isHidden = false
            lblNorecord.text = "No record found"
            tblView.isHidden = true
        }
        else{
            lblNorecord.isHidden = true
            tblView.isHidden = false
            let task = arydata[indexPath.row]
            let newStr:String = "Q" + String(task.Id)
            cell.lbl_ques_no?.text = newStr
            cell.lbl_question?.text = task.Question_Name
        }
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let id = String(indexPath.row)
        appDelegate.appstrindexval = id
        if searchController.isActive && searchController.searchBar.text != "" && filteredData.count > 0{
            appDelegate.aryglobal = filteredData
        }else{
            appDelegate.aryglobal = arydata}
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "QueAnsVC") as! QueAnsVC
        self.navigationController?.pushViewController(nextViewController, animated: true)
    }
    // Mark: Custom Method
    func GetDataFromDataBase() {
        let qstType = appDelegate.qstType
        switch qstType {
        case .all:
            arydata = QueAns.rows(order:"Id ASC") as! [QueAns]
            self.navigationItem.title=""
            self.navigationItem.title="All Questions"
        case .fav:
            arydata = QueAns.rows(filter: "Is_Favourite = 1",order:"Id ASC") as! [QueAns]
            self.navigationItem.title=""
            self.navigationItem.title="Favourite Questions"
            print("favqst")
        }
        let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent("Intewrview_QueAns.db")
        print("doc path\(fileURL)")
    }
}
// MARK: - Extension
extension ViewController : SlideMenuControllerDelegate {
    func leftWillOpen() {
        print("SlideMenuControllerDelegate: leftWillOpen")
    }
    func leftDidOpen() {
        print("SlideMenuControllerDelegate: leftDidOpen")
    }
    func leftWillClose() {
        print("SlideMenuControllerDelegate: leftWillClose")
    }
    func leftDidClose() {
        print("SlideMenuControllerDelegate: leftDidClose")
    }
    func rightWillOpen() {
        print("SlideMenuControllerDelegate: rightWillOpen")
    }
    func rightDidOpen() {
        print("SlideMenuControllerDelegate: rightDidOpen")
    }
    func rightWillClose() {
        print("SlideMenuControllerDelegate: rightWillClose")
    }
    func rightDidClose() {
        print("SlideMenuControllerDelegate: rightDidClose")
    }
}
extension UIViewController {
    func setNavigationBarItem() {
        self.navigationController?.navigationBar.titleTextAttributes =
            [NSForegroundColorAttributeName: UIColor.yellow]
        self.addLeftBarButtonWithImage((UIImage(named:"menu_icon")?.withRenderingMode(.alwaysOriginal))!)
        self.addRightBarButtonWithImage((UIImage(named:"search")?.withRenderingMode(.alwaysOriginal))!)
        self.slideMenuController()?.removeLeftGestures()
        self.slideMenuController()?.removeRightGestures()
        self.slideMenuController()?.addLeftGestures()
        self.slideMenuController()?.addRightGestures()
    }
    func sethidden() {
        self.navigationItem.rightBarButtonItem?.isEnabled = false
    }
    func removeNavigationBarItem() {
        self.navigationItem.leftBarButtonItem = nil
        self.navigationItem.rightBarButtonItem = nil
        self.slideMenuController()?.removeLeftGestures()
        self.slideMenuController()?.removeRightGestures()
    }
}
extension UIColor {
    convenience init(red: Int, green: Int, blue: Int) {
        assert(red >= 0 && red <= 255, "Invalid red component")
        assert(green >= 0 && green <= 255, "Invalid green component")
        assert(blue >= 0 && blue <= 255, "Invalid blue component")
        self.init(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: 1.0)
    }
    convenience init(netHex:Int) {
        self.init(red:(netHex >> 16) & 0xff, green:(netHex >> 8) & 0xff, blue:netHex & 0xff)
    }
}
