//
//  Task.swift
//  SQLiteDB-iOS
//
//  Created by Fahim Farook on 6/11/15.
//  Copyright © 2015 RookSoft Pte. Ltd. All rights reserved.
//

#if os(iOS)
	import UIKit
#else
	import AppKit
#endif

class QueAns:SQLTable {
    var Id = -1
	var Question_Name = ""
	var Question_Type = -1
    var Answer = ""
    var Is_Favourite = "0"
}
