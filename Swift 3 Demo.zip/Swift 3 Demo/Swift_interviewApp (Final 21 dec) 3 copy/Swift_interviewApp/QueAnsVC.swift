//
//  QueAnsVC.swift
//  Swift_interviewApp
//
//  Created by heli on 11/18/16.
//  Copyright © 2016 com.zaptechsolution. All rights reserved.
//

import UIKit
import GoogleMobileAds
class QueAnsVC: UIViewController {
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    var finalindex : Int = -1
    var aryforfav = [QueAns]()
    var isshowans : Bool = false
    var strqueno:String = ""
    var strquetext:String = ""
    var stranstext:String = ""
    var strfav:String = ""
    var strid:String = ""
    @IBOutlet var btnPrev: UIButton!
    @IBOutlet var btnNext: UIButton!
    @IBAction func ActionbtnNext(_ sender: AnyObject) {
        let isIndexValid = appDelegate.aryglobal.indices.contains(finalindex + 1)
        if(isIndexValid){
            finalindex = finalindex + 1}
        isshowans = false
        datafill(finalindex: finalindex)
    }
    @IBAction func ActionbtnPrev(_ sender: AnyObject) {
        let isIndexValid = appDelegate.aryglobal.indices.contains(finalindex - 1)
        if(isIndexValid){
            finalindex = finalindex - 1 }
        isshowans = false
        datafill(finalindex: finalindex)
    }
    @IBOutlet var ViewAdvertise: GADBannerView!
    @IBOutlet var tblQuestionList: UITableView!
    @IBAction func btnShowAns(_ sender: AnyObject) {
        isshowans = true
        self.tblQuestionList .reloadData()
    }
    func back(sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }
    // MARK: View Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
//        ViewAdvertise.adUnitID = "ca-app-pub-5831605216718236/2956103704"
//        ViewAdvertise.rootViewController = self
//        ViewAdvertise.load(GADRequest())
        super.viewDidLoad()
        self.navigationItem.title = "Questions"
        self.navigationController?.navigationBar.tintColor = UIColor(red: 0x8C, green: 0xC6, blue: 0x26)
        self.tblQuestionList.estimatedRowHeight = 280.0
        self.tblQuestionList.rowHeight = UITableViewAutomaticDimension
    }
    override func viewWillAppear(_ animated: Bool) {
        var myString : String
        myString = appDelegate.appstrindexval
        finalindex = Int(myString)!
        datafill(finalindex: finalindex)
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationItem.title=""
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        //        NotificationCenter.default.addObserver(forName: .UIContentSizeCategoryDidChange, object: .none, queue: OperationQueue.main) { [weak self] _ in
        //            self?.tblQuestionList.reloadData()
        // }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    //MARK: Custom Method
    func toggleLikes()
    {
        let task = appDelegate.aryglobal[finalindex]
        aryforfav = QueAns.rows(filter: "Id == \(task.Id)",order:"Id ASC") as! [QueAns]
        let isIndexValid = aryforfav.indices.contains(0)
        if(isIndexValid){
            let newtask = aryforfav[0]
            if(newtask.Is_Favourite == "1"){
                let task = aryforfav[0]
                task.Is_Favourite = "0"
                if task.save() != 0 {
                }
            }
            else{
                let task = aryforfav[0]
                task.Is_Favourite = "1"
                if task.save() != 0 {
                    
                }
            }
        }
        displaylikes()
    }
    func displaylikes(){
        let task = appDelegate.aryglobal[finalindex]
        
        aryforfav = QueAns.rows(filter: "Id == \(task.Id)",order:"Id ASC") as! [QueAns]
        let newtask = aryforfav[0]
        if newtask.Is_Favourite.isEqual("1") {
            let rightButton: UIBarButtonItem = UIBarButtonItem(image: (UIImage(named:"liked")?.withRenderingMode(.alwaysOriginal))!, style: UIBarButtonItemStyle.plain, target: self, action: #selector(self.toggleLikes))
            navigationItem.rightBarButtonItem = rightButton;
        }
        else {
            let rightButton: UIBarButtonItem = UIBarButtonItem(image: (UIImage(named:"like")?.withRenderingMode(.alwaysOriginal))!, style: UIBarButtonItemStyle.plain, target: self, action: #selector(self.toggleLikes))
            navigationItem.rightBarButtonItem = rightButton;
        }
    }
    func GetDataFromDataBase() {
        let qstType = appDelegate.qstType
        
        switch qstType {
        case .all:
            self.navigationItem.title="All Questions"
        case .fav:
            self.navigationItem.title="Favourite Questions"
            btnPrev.isEnabled = false
            btnPrev.isHidden = true
            btnNext.isEnabled = false
            btnNext.isHidden = true
        }
    }
    func datafill(finalindex : Int)
    {
        GetDataFromDataBase()
        let isIndexValid = appDelegate.aryglobal.indices.contains(finalindex)
        
        if(appDelegate.aryglobal.indices.contains(finalindex - 1)){
            btnPrev.isEnabled = true
        }
        else{
            btnPrev.isEnabled = false
        }
        if(appDelegate.aryglobal.indices.contains(finalindex + 1)){
            btnNext.isEnabled = true
        }
        else{
            btnNext.isEnabled = false
        }
        if (isIndexValid) {
            let task = appDelegate.aryglobal[finalindex]
            self.tblQuestionList.reloadData()
            strid = String(task.Id)
            strqueno = "Q" + String(task.Id)
            stranstext = task.Answer
            strquetext = task.Question_Name
            strfav = task.Is_Favourite
            displaylikes()
        }
    }
}
// MARK: Extension Table view Method
extension QueAnsVC : UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView:UITableView, numberOfRowsInSection section:Int) -> Int {
        return 1
    }
    func tableView(_ tableView:UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "QueAnsTableViewCell", for: indexPath) as! QueAnsTableViewCell
        cell.lblQstTitle.font = UIFont.preferredFont(forTextStyle: .body)
        cell.txtViewAnswer.font = UIFont.preferredFont(forTextStyle: .body)
        cell.objshowhideans.setImage(UIImage(named: "showans")?.withRenderingMode(.alwaysOriginal), for: .normal)
        cell.lblQstTitle.text = strquetext
        cell.lblQstNo.text = strqueno
        cell.txtViewAnswer.layer.borderColor = UIColor.lightGray.cgColor
        cell.txtViewAnswer.layer.borderWidth = 1.0;
        if(isshowans){
            if (cell.txtViewAnswer.text == stranstext) {
                cell.txtViewAnswer.text = ""
                cell.txtViewAnswer.isHidden = true
                cell.objshowhideans.setImage(UIImage(named: "showans")?.withRenderingMode(.alwaysOriginal), for: .normal)
            }
            else{
                cell.txtViewAnswer.isHidden = false
                cell.txtViewAnswer.text = stranstext
                cell.objshowhideans.setImage(UIImage(named: "hide_ans")?.withRenderingMode(.alwaysOriginal), for: .normal)
            }
        }
        else{
            cell.txtViewAnswer.isHidden = true
            cell.txtViewAnswer.text = ""
        }
        return cell
    }
}
