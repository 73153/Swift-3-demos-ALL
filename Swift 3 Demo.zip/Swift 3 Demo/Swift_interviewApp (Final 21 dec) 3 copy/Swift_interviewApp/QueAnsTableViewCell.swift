//
//  QueAnsTableViewCell.swift
//  Swift_interviewApp
//
//  Created by heli on 11/29/16.
//  Copyright © 2016 com.zaptechsolution. All rights reserved.
//

import UIKit
class QueAnsTableViewCell: UITableViewCell {

    @IBOutlet var objshowhideans: UIButton!
    @IBOutlet var txtViewAnswer: UITextView!
    @IBOutlet var lblQstTitle: UILabel!
    @IBOutlet var lblQstNo: UILabel!
    let db = SQLiteDB.sharedInstance
    var data = [QueAns]()
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
