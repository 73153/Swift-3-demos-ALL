//
//  MyMenuTableViewController.swift
//  SwiftSideMenu
//
//  Created by Evgeny Nazarov on 29.09.14.
//  Copyright (c) 2014 Evgeny Nazarov. All rights reserved.
//

import UIKit
class MyMenuTableViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    @IBOutlet weak var tableView: UITableView?
    
    var AryVCnames:[String] = ["All Questions","Favourite Questions"]
    
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    let blackcolor = UIColor(red: 16/255.0, green: 27/255.0, blue: 57/255.0, alpha: 1.0)
    let objViewControllerMain = ViewController()
      var selectedMenuItem : Int = 0
    // MARK: Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        selectedMenuItem = 0
        view.backgroundColor = blackcolor
        tableView?.backgroundColor = blackcolor
        tableView?.contentInset = UIEdgeInsetsMake(0, 0, 0, 0) //
        tableView?.separatorStyle = .none
        tableView?.backgroundColor = UIColor.clear
        tableView?.scrollsToTop = false
        // Preserve selection between presentations
        self.tableView?.delegate = self
        self.tableView?.dataSource = self
        _ = IndexPath(row: 0, section: 0)
        self.tableView?.reloadData()
        let headerView = UIView(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(200), height: CGFloat(180)))
        let imageView = UIImageView(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(280), height: CGFloat(180)))
        headerView.addSubview(imageView)
        let image = UIImage(named: "header")!
        imageView.image = image
        self.tableView?.tableHeaderView = headerView
        //Edit
        let indexPath = IndexPath(row: 0, section: 0)
        self.tableView?.selectRow(at: indexPath, animated: true, scrollPosition: UITableViewScrollPosition.none)
       // imagepress = true
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        NotificationCenter.default.addObserver(forName: .UIContentSizeCategoryDidChange, object: .none, queue: OperationQueue.main) {
            [weak self] _ in
            self?.tableView?.reloadData()
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
    }
        // MARK: - Table view Method
    private func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        return AryVCnames.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
                let cell :sidebarcell = tableView.dequeueReusableCell(withIdentifier: "CustomCell") as! sidebarcell
                let Currentrow: Int = indexPath.row
            if Currentrow == selectedMenuItem {
            if Currentrow == 0 {
                cell.img_sidebar.image = UIImage(named:"all_ques_icon")
            }
            else{
                cell.img_sidebar.image = UIImage(named:"fav_ques_icon")
            }
            cell.lbl_sidebar.textColor = UIColor(red: 0x8C, green: 0xC6, blue: 0x26)
        }
        else {
            cell.lbl_sidebar.textColor = UIColor.white
            if Currentrow == 0 {
                cell.img_sidebar.image = UIImage(named:"all_ques_icon_white")
            }
            else{
                cell.img_sidebar.image = UIImage(named:"fav_ques_icon_white")
            }
        }
        //  cell.lbl_sidebar.font = UIFont.preferredFont(forTextStyle: UIFontTextStyle.headline)
        cell.backgroundColor = blackcolor
        cell.lbl_sidebar.text = AryVCnames[indexPath.row]
        cell.selectionStyle = .none
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50.0
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
         print("did select row: \(indexPath.row)")
        let Currentrow: Int = indexPath.row
            if Currentrow == 0 {
            let cell : sidebarcell = self.tableView?.cellForRow(at: indexPath) as! sidebarcell
            cell.lbl_sidebar.textColor = UIColor(red: 0x8C, green: 0xC6, blue: 0x26)
            cell.img_sidebar.image = UIImage(named:"all_ques_icon")
            let indexPath : IndexPath = IndexPath(item: 1, section: 0)
            let cell1 : sidebarcell = self.tableView?.cellForRow(at: indexPath) as! sidebarcell
            cell1.lbl_sidebar.textColor = UIColor.white
            cell1.img_sidebar.image = UIImage(named:"fav_ques_icon_white")
        }
        else {
            let cell : sidebarcell = self.tableView?.cellForRow(at: indexPath) as! sidebarcell
            cell.lbl_sidebar.textColor = UIColor(red: 0x8C, green: 0xC6, blue: 0x26)
            cell.img_sidebar.image = UIImage(named:"fav_ques_icon")
            
            let indexPath : IndexPath = IndexPath(item: 0, section: 0)
            let cell1 : sidebarcell = self.tableView?.cellForRow(at: indexPath) as! sidebarcell
            cell1.lbl_sidebar.textColor = UIColor.white
            cell1.img_sidebar.image = UIImage(named:"all_ques_icon_white")
        }
        let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main",bundle: nil)
        
        let cell = tableView.cellForRow(at: indexPath) as! sidebarcell
        var destViewController : UIViewController
        switch (indexPath.row) {
        case 0:
            destViewController = mainStoryboard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
            appDelegate.qstType = .all
                       break
            
        case 1:
            destViewController = mainStoryboard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
            appDelegate.qstType = .fav
                        break
            
        default:
            destViewController = mainStoryboard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
            break
        }

        
        let nvc: UINavigationController = UINavigationController(rootViewController: destViewController)
        
        nvc.navigationBar.barTintColor = UIColor(red: CGFloat(16.0 / 255.0), green: CGFloat(27.0 / 255.0), blue: CGFloat(57.0 / 255.0), alpha: CGFloat(0.0 / 255.0))
        
        self.slideMenuController()?.changeMainViewController(nvc, close: true)
        
    }
}
