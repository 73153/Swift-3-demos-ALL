//
//  Constants.swift
//  InstagramLogin
//
//  Created by AJK on 10/17/16.
//  Copyright © 2016 ajk. All rights reserved.
//

import UIKit

class Constants {
    
    let instagramClientID = "69ec7c55b65b4813946a2a202626e283"
    let instagramSecret = "a832753f00294d4c982c9adadda1c804"
    let redirectURI = "https://com.ajk.demo/"
    let authorizationEndPoint = "https://api.instagram.com/oauth/authorize/"
    let accessTokenEndPoint = "https://api.instagram.com/oauth/access_token/"
    
}
