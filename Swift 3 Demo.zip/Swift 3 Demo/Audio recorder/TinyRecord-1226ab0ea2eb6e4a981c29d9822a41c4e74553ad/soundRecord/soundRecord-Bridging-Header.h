//
//  soundRecord-Bridging-Header.h
//  soundRecord
//
//  Created by Alexey Savchenko on 10.01.17.
//  Copyright © 2017 Alexey Savchenko. All rights reserved.
//

#ifndef soundRecord_Bridging_Header_h
#define soundRecord_Bridging_Header_h

#endif /* soundRecord_Bridging_Header_h */

#import "EZAudio.h"
#import "EZAudioDevice.h"
#import "EZAudioDevice.h"
#import "EZAudioDisplayLink.h"
